<?php
/**
 * FileFlow - Database Configuration
 * 
 * MySQL database connection using PDO.
 * Update credentials for your hosting environment.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'ashikone_fileflowdb');
define('DB_USER', 'ashikone_fileflowuser');
define('DB_PASS', 'Ashik@21032001');
define('DB_CHARSET', 'utf8mb4');

/**
 * Get PDO database connection
 * 
 * @return PDO
 * @throws PDOException
 */
function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=%s',
            DB_HOST,
            DB_NAME,
            DB_CHARSET
        );

        $timezoneOffset = (new DateTime())->format('P'); // e.g. +06:00
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci, time_zone = '{$timezoneOffset}'"
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new PDOException("Database connection failed. Please check configuration.");
        }
    }

    return $pdo;
}
